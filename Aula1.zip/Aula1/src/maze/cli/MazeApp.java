package maze.cli;

import java.util.Scanner;
import maze.logic.*;

public class MazeApp{
	
	/*public Maze newGame(String[][] lo){
		Maze myMaze = null;
		myMaze.setLayout(lo);
		return myMaze;
	}*/
	static Hero luke=new Hero();
	static Dragon smaug=new Dragon();
	static Sword excalibur=new Sword();
	
	public static void main(String[] args){
		char[][] lo={{'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'},
				{'X', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 'X'},
				{'X', ' ', 'X', 'X', ' ', 'X', ' ', 'X', ' ', 'X'},
				{'X', ' ', 'X', 'X', ' ', 'X', ' ', 'X', ' ', 'X'},
				{'X', ' ', 'X', 'X', ' ', 'X', ' ', 'X', ' ', 'X'},
				{'X', ' ', ' ', ' ', ' ', ' ', ' ', 'X', ' ', 'S'},
				{'X', ' ', 'X', 'X', ' ', 'X', ' ', 'X', ' ', 'X'},
				{'X', ' ', 'X', 'X', ' ', 'X', ' ', 'X', ' ', 'X'},
				{'X', ' ', 'X', 'X', ' ', ' ', ' ', ' ', ' ', 'X'},
				{'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'}		
		};
		
		Maze myMaze=new Maze(lo);
		
		myMaze.printMaze(luke, smaug, excalibur);
		
		char movement;
		
		
		/*
		 * TODO: separar ciclo em antes de hasWon e depois de hasWon
		 */
		while(true){
			Scanner input=new Scanner(System.in);
			movement = input.next().charAt(0);
			luke.move(myMaze, excalibur, smaug, movement);
			System.out.println(luke.getX() +" " + luke.getY());
			System.out.println(myMaze.getSymbol(luke.getX(), luke.getY()));
			smaug.move(myMaze, luke);
			if(luke.getDead()){
				System.out.print("You Died!!!");
				break;
			}
			myMaze.printMaze(luke, smaug, excalibur);
			//System.out.print('\n');
			//myMaze.printField();

		}
	}
	
	
}

