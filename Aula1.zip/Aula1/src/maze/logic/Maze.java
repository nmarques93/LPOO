
package maze.logic;

import java.util.Scanner;
import java.util.Random;

public class Maze {
	
	
	//char[][] layout=new char[10][10];
	protected char [][] layout=new char[10][10];
	protected Hero luke;
	protected Dragon smaug;
	
	protected int x=1,y=1;
	//int xdragon=3, ydragon=1;
	//protected char status='H';
	protected boolean ended=false;
	
	public Maze(char[][] layout){
		this.layout=layout;
	}
	
	public boolean getEnded(){
		return this.ended;
	}
	
	public char getSymbol(int x, int y){
		return this.layout[x][y];
	}
	
	public void setSymbol(int x, int y, char s){
		this.layout[x][y]=s;
	}
	
	public char[][] getLayout(){
		return this.layout;
	}
	
	public void printMaze(Hero luke, Dragon smaug, Sword excalibur){
		
		this.layout[excalibur.getX()][excalibur.getY()]=excalibur.getSymbol();
		this.layout[smaug.getX()][smaug.getY()]=smaug.getSymbol();
		this.layout[luke.getX()][luke.getY()]=luke.getSymbol();
		
		for (int i = 0; i < 10; i++) {
		    for (int j = 0; j < this.layout[0].length; j++) {
		        System.out.print(layout[i][j]+ " ");
		    }
		    System.out.print('\n');
		}
		
		
	}
	
	public void printField(){
		for (int i = 0; i < 10; i++) {
		    for (int j = 0; j < this.layout[0].length; j++) {
		    	if(this.layout[i][j]=='H' || this.layout[i][j]=='D' || this.layout[i][j]=='E')
		    		this.layout[i][j]=' ';
		        System.out.print(this.layout[i][j] + ' ');
		    }
		    System.out.print('\n');
		}
	}
	
	/*public void changePos(char move){
		
		switch(move){
		case 'u':
			if(this.layout[x-1][y]==' ' || this.layout[x-1][y]=='D'){
				this.layout[x-1][y]=status;
				this.layout[x][y]=' ';
				x--;
			} else if(this.layout[x-1][y]=='X'){
				System.out.println("Invalid move!");
			} else if(this.layout[x-1][y]=='E'){
				status='A';
				this.layout[x-1][y]=status;
				this.layout[x][y]=' ';
				x--;
			}
			break;
		case 'd':
			if(this.layout[x+1][y]==' ' || this.layout[x+1][y]=='D'){
				this.layout[x+1][y]=status;
				this.layout[x][y]=' ';
				x++;
			} else if(this.layout[x+1][y]=='X'){
				System.out.println("Invalid move!");
			} else if(this.layout[x+1][y]=='E'){
				status='A';
				this.layout[x+1][y]=status;
				this.layout[x][y]=' ';
				x++;
			}
			break;
		case 'l':
			if(this.layout[x][y-1]==' ' || this.layout[x-1][y]=='D'){
				this.layout[x][y-1]=status;
				this.layout[x][y]=' ';
				y--;
			} else if(this.layout[x][y--]=='X'){
				System.out.println("Invalid move!");
			} else if(this.layout[x][y-1]=='E'){
				status='A';
				this.layout[x][y-1]=status;
				this.layout[x][y]=' ';
				y--;
			}
			break;
		case 'r':
			if(this.layout[x][y+1]==' ' || this.layout[x-1][y]=='D'){
				this.layout[x][y+1]=status;
				this.layout[x][y]=' ';
				y++;
			} else if(this.layout[x][y+1]=='X'){
				System.out.println("Invalid move!");
			} else if(this.layout[x][y+1]=='E'){
				status='A';
				this.layout[x][y+1]=status;
				this.layout[x][y]=' ';
				y++;
			} else if(this.layout[x][y+1]=='S'){
				if(status=='H')
					System.out.println("You have to kill the dragon first!");
				else{
					System.out.println("Congrats!! You won the game!");
					ended=true;
				}
			}
			break;
		}
		//Random posGenerator=new Random();
		//int randomPos = posGenerator.nextInt(3);
		
		if(x==xdragon && y==ydragon && status=='H'){
			System.out.println("You died!!!");
			ended=true;
		}
			
		else if(x==xdragon && y==ydragon && status=='A'){
			System.out.println("You just killed the motherfucker!!");
			this.layout[xdragon][ydragon]='A';
		}
	}*/
}