package maze.logic;

public class Sword extends Element{
	public Sword(){
		symbol='E';
		posx=8;
		posy=1;
	}
}